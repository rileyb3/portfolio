"use client";

import { useRef } from "react";
import RevealOnScroll from "./RevealOnScroll";

export type MoveClip = {
  src: string;
  poster?: string;
  // What's being compared — the one thing that differs between clips.
  variable: string;
  // Optional second line: the detail that variable changes about the move.
  note?: string;
};

// The same move attempted under different conditions, side by side and
// looping, so the variable is the only thing that changes between panes.
// Comparison is the whole point, so the clips restart together on demand:
// watching four loops drift out of phase makes them impossible to read
// against each other.
export default function MoveComparison({
  clips,
  label,
}: {
  clips: MoveClip[];
  label?: string;
}) {
  const refs = useRef<(HTMLVideoElement | null)[]>([]);

  const replayAll = () => {
    refs.current.forEach((v) => {
      if (!v) return;
      v.currentTime = 0;
      // play() rejects if the browser blocks it (low power mode, say) —
      // swallow it rather than throwing an unhandled rejection.
      void v.play().catch(() => {});
    });
  };

  return (
    <RevealOnScroll className="relative left-1/2 w-screen -translate-x-1/2 px-6 py-10 sm:px-10 sm:py-14">
      <div className="mx-auto max-w-6xl">
        <div className="mb-6 flex flex-wrap items-center justify-between gap-4">
          {label && (
            <h3 className="text-xs font-semibold uppercase tracking-[0.3em] text-accent3">
              {label}
            </h3>
          )}
          <button
            type="button"
            onClick={replayAll}
            className="rounded-full border border-white/15 px-4 py-1.5 text-xs font-semibold uppercase tracking-wide text-paper transition hover:border-white/40 hover:bg-white/5"
          >
            Replay all
          </button>
        </div>

        <div className="grid grid-cols-2 gap-3 sm:gap-4 lg:grid-cols-4">
          {clips.map((clip, i) => (
            <figure key={clip.src}>
              <div className="overflow-hidden rounded-xl border border-white/10 bg-surface2">
                <video
                  ref={(el) => {
                    refs.current[i] = el;
                  }}
                  src={clip.src}
                  poster={clip.poster}
                  // Muted + playsInline + loop is what lets these autoplay
                  // on iOS at all; without muted they simply never start.
                  autoPlay
                  loop
                  muted
                  playsInline
                  className="block aspect-[9/16] w-full object-cover"
                />
              </div>
              <figcaption className="mt-3">
                <p className="text-sm font-semibold text-paper">
                  {clip.variable}
                </p>
                {clip.note && (
                  <p className="mt-1 text-sm leading-relaxed text-muted">
                    {clip.note}
                  </p>
                )}
              </figcaption>
            </figure>
          ))}
        </div>
      </div>
    </RevealOnScroll>
  );
}
